# War3-SizeLimit-Bypass
Hack to bypass War3 map size limit!

