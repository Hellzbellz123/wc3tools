Move FixSizeLimit.mix to the folder with Warcraft3 or rename FixSizeLimit.mix into FixSizeLimit.dll and load by means of an injector.

Create in the folder with Warcraft3 the empty file with name "forcefixsizelimit" for  completely clean a size limit, but then it will be found by some anti-hack!